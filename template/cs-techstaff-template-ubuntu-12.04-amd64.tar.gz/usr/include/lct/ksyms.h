typedef struct {
        unsigned short uni;
        const char *name;
} sym;

typedef struct {
	char **table;
	int size;
} syms_entry;

extern syms_entry syms[];

struct syn {
	char *synonym;
	char *official_name;
};
extern struct syn synonyms[];

extern const int syms_size;
extern const int syn_size;
extern const int charsets_size;

extern int set_charset(const char *name);
extern int add_number(int code);
extern int add_capslock(int code);
extern const char *codetoksym(int code);
extern void list_charsets(FILE *f);

