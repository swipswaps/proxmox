update-rc.d console-screen.sh start 90 S .
