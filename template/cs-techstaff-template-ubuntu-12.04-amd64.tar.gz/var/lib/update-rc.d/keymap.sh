update-rc.d keymap.sh start 05 S .
