update-rc.d modules_dep.sh defaults
